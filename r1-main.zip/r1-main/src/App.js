import './App.css';
import As from "./components/As-1"
function App() {
  return (
<div><As/></div>
  );
}

export default App;
